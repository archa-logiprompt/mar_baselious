<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Incomehead_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * This funtion takes id as a parameter and will fetch the record.
     * If id is not provided, then it will fetch all the records form the table.
     * @param int $id
     * @return mixed
     */
    public function get($id = null) {
		
        $admin=$this->session->userdata('admin');
        $centre_id=$admin['centre_id'];
        $this->db->select()->from('income_head');
        $this->db->where('centre_id',$centre_id);
        if ($id != null) {
            $this->db->where('id', $id);
        } else {
            $this->db->order_by('id');
			
        }
        $query = $this->db->get();
        if ($id != null) {
            return $query->row_array();
        } else {
            return $query->result_array();
        }
    }

    /**
     * This function will delete the record based on the id
     * @param $id
     */
    public function remove($id) {
        $this->db->where('id', $id);
        $this->db->delete('income_head');
    }

    /**
     * This function will take the post data passed from the controller
     * If id is present, then it will do an update
     * else an insert. One function doing both add and edit.
     * @param $data
     */
    public function add($data) {
        if (isset($data['id'])) {
            $this->db->where('id', $data['id']);
            $this->db->update('income_head', $data);
        } else {
            $this->db->insert('income_head', $data);
        }
    }
	
	
	public function mess_incomehead($data) {
		
		 if (isset($data['id'])) {
            $this->db->where('id', $data['id']);
            $this->db->update('mess_incomehead', $data);
        } else {
            $this->db->insert('mess_incomehead', $data);
            return $this->db->insert_id();
        }
    }
	
	
	
	
	
	public function get_headlist($id = null) {
		
        
        $this->db->select()->from('mess_incomehead');
       if ($id != null) {
            $this->db->where('id', $id);
        } else {
            $this->db->order_by('id');
			
        }
        $query = $this->db->get();
        if ($id != null) {
            return $query->row_array();
        } else {
            return $query->result_array();
        }
    }
	
	
	 public function remove_messhead($id) {
        $this->db->where('id', $id);
        $this->db->delete('mess_incomehead');
    }
	
	
	

}
